// Base44 removed. Shim to satisfy imports.
export const base44 = {};
